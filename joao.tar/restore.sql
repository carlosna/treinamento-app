--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.13
-- Dumped by pg_dump version 9.6.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.item DROP CONSTRAINT fkorywub2ms5p9l57d5v77r252q;
ALTER TABLE ONLY public.product DROP CONSTRAINT fklgbo1awuhjmqsihofofq3tbuo;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT fkbd4l5kphorgnikpt73os83lrd;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT fk7rl0tqgxogwpuxttukl4xsq7m;
ALTER TABLE ONLY public.t_order_order_line DROP CONSTRAINT fk3aqi5l05d51b1bkigjt0v6bwa;
ALTER TABLE ONLY public.t_order_order_line DROP CONSTRAINT fk31k94wis8jfbsi72sareeh32;
ALTER TABLE ONLY public.customer DROP CONSTRAINT fk2r67e919tj04df0noxm1f6bxv;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT fk1x9aqv137m1pjc1atcx66hkaj;
ALTER TABLE ONLY public.t_order_order_line DROP CONSTRAINT uk_jo44h7yfc34r15gudii8hsq9q;
ALTER TABLE ONLY public.t_order_order_line DROP CONSTRAINT t_order_order_line_pkey;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_pkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_pkey;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_pkey;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_pkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_pkey;
ALTER TABLE ONLY public.country DROP CONSTRAINT country_pkey;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_pkey;
DROP TABLE public.t_order_order_line;
DROP TABLE public.purchase_order;
DROP TABLE public.product;
DROP TABLE public.order_line;
DROP TABLE public.item;
DROP SEQUENCE public.hibernate_sequence;
DROP TABLE public.customer;
DROP TABLE public.country;
DROP TABLE public.category;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    id bigint NOT NULL,
    description character varying(3000) NOT NULL,
    name character varying(30) NOT NULL,
    version integer
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    id bigint NOT NULL,
    iso3 character varying(3) NOT NULL,
    iso_code character varying(2) NOT NULL,
    name character varying(80) NOT NULL,
    numcode character varying(3) NOT NULL,
    printable_name character varying(80) NOT NULL,
    version integer
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id bigint NOT NULL,
    date_of_birth date,
    email character varying(255),
    first_name character varying(50) NOT NULL,
    city character varying(50) NOT NULL,
    state character varying(255),
    street1 character varying(50) NOT NULL,
    street2 character varying(255),
    zip_code character varying(10) NOT NULL,
    last_name character varying(50) NOT NULL,
    login character varying(10) NOT NULL,
    password character varying(256) NOT NULL,
    role integer,
    telephone character varying(255),
    uuid character varying(256),
    version integer,
    country_id bigint
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item (
    id bigint NOT NULL,
    description character varying(3000) NOT NULL,
    image_path character varying(255) NOT NULL,
    name character varying(30) NOT NULL,
    unit_cost real NOT NULL,
    version integer,
    product_fk bigint NOT NULL
);


ALTER TABLE public.item OWNER TO postgres;

--
-- Name: order_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_line (
    id bigint NOT NULL,
    quantity integer NOT NULL,
    version integer,
    item_fk bigint NOT NULL,
    CONSTRAINT order_line_quantity_check CHECK ((quantity >= 1))
);


ALTER TABLE public.order_line OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    id bigint NOT NULL,
    description character varying(3000) NOT NULL,
    name character varying(30) NOT NULL,
    version integer,
    category_fk bigint NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: purchase_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_order (
    id bigint NOT NULL,
    credit_card_expiry_date character varying(5) NOT NULL,
    credit_card_number character varying(30) NOT NULL,
    credit_card_type integer,
    city character varying(50) NOT NULL,
    state character varying(255),
    street1 character varying(50) NOT NULL,
    street2 character varying(255),
    zip_code character varying(10) NOT NULL,
    discount real,
    discount_rate real,
    order_date date,
    total real,
    totalwithvat real,
    totalwithoutvat real,
    vat real,
    vat_rate real,
    version integer,
    customer_fk bigint NOT NULL,
    country_id bigint
);


ALTER TABLE public.purchase_order OWNER TO postgres;

--
-- Name: t_order_order_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.t_order_order_line (
    order_fk bigint NOT NULL,
    order_line_fk bigint NOT NULL
);


ALTER TABLE public.t_order_order_line OWNER TO postgres;

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (id, description, name, version) FROM stdin;
\.
COPY public.category (id, description, name, version) FROM '$$PATH$$/2183.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (id, iso3, iso_code, name, numcode, printable_name, version) FROM stdin;
\.
COPY public.country (id, iso3, iso_code, name, numcode, printable_name, version) FROM '$$PATH$$/2184.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, date_of_birth, email, first_name, city, state, street1, street2, zip_code, last_name, login, password, role, telephone, uuid, version, country_id) FROM stdin;
\.
COPY public.customer (id, date_of_birth, email, first_name, city, state, street1, street2, zip_code, last_name, login, password, role, telephone, uuid, version, country_id) FROM '$$PATH$$/2185.dat';

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hibernate_sequence', 1, false);


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item (id, description, image_path, name, unit_cost, version, product_fk) FROM stdin;
\.
COPY public.item (id, description, image_path, name, unit_cost, version, product_fk) FROM '$$PATH$$/2186.dat';

--
-- Data for Name: order_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_line (id, quantity, version, item_fk) FROM stdin;
\.
COPY public.order_line (id, quantity, version, item_fk) FROM '$$PATH$$/2187.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (id, description, name, version, category_fk) FROM stdin;
\.
COPY public.product (id, description, name, version, category_fk) FROM '$$PATH$$/2188.dat';

--
-- Data for Name: purchase_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_order (id, credit_card_expiry_date, credit_card_number, credit_card_type, city, state, street1, street2, zip_code, discount, discount_rate, order_date, total, totalwithvat, totalwithoutvat, vat, vat_rate, version, customer_fk, country_id) FROM stdin;
\.
COPY public.purchase_order (id, credit_card_expiry_date, credit_card_number, credit_card_type, city, state, street1, street2, zip_code, discount, discount_rate, order_date, total, totalwithvat, totalwithoutvat, vat, vat_rate, version, customer_fk, country_id) FROM '$$PATH$$/2189.dat';

--
-- Data for Name: t_order_order_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.t_order_order_line (order_fk, order_line_fk) FROM stdin;
\.
COPY public.t_order_order_line (order_fk, order_line_fk) FROM '$$PATH$$/2190.dat';

--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: order_line order_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line
    ADD CONSTRAINT order_line_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: purchase_order purchase_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT purchase_order_pkey PRIMARY KEY (id);


--
-- Name: t_order_order_line t_order_order_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_order_order_line
    ADD CONSTRAINT t_order_order_line_pkey PRIMARY KEY (order_fk, order_line_fk);


--
-- Name: t_order_order_line uk_jo44h7yfc34r15gudii8hsq9q; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_order_order_line
    ADD CONSTRAINT uk_jo44h7yfc34r15gudii8hsq9q UNIQUE (order_line_fk);


--
-- Name: order_line fk1x9aqv137m1pjc1atcx66hkaj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line
    ADD CONSTRAINT fk1x9aqv137m1pjc1atcx66hkaj FOREIGN KEY (item_fk) REFERENCES public.item(id);


--
-- Name: customer fk2r67e919tj04df0noxm1f6bxv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT fk2r67e919tj04df0noxm1f6bxv FOREIGN KEY (country_id) REFERENCES public.country(id);


--
-- Name: t_order_order_line fk31k94wis8jfbsi72sareeh32; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_order_order_line
    ADD CONSTRAINT fk31k94wis8jfbsi72sareeh32 FOREIGN KEY (order_fk) REFERENCES public.purchase_order(id);


--
-- Name: t_order_order_line fk3aqi5l05d51b1bkigjt0v6bwa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.t_order_order_line
    ADD CONSTRAINT fk3aqi5l05d51b1bkigjt0v6bwa FOREIGN KEY (order_line_fk) REFERENCES public.order_line(id);


--
-- Name: purchase_order fk7rl0tqgxogwpuxttukl4xsq7m; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT fk7rl0tqgxogwpuxttukl4xsq7m FOREIGN KEY (customer_fk) REFERENCES public.customer(id);


--
-- Name: purchase_order fkbd4l5kphorgnikpt73os83lrd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT fkbd4l5kphorgnikpt73os83lrd FOREIGN KEY (country_id) REFERENCES public.country(id);


--
-- Name: product fklgbo1awuhjmqsihofofq3tbuo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT fklgbo1awuhjmqsihofofq3tbuo FOREIGN KEY (category_fk) REFERENCES public.category(id);


--
-- Name: item fkorywub2ms5p9l57d5v77r252q; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT fkorywub2ms5p9l57d5v77r252q FOREIGN KEY (product_fk) REFERENCES public.product(id);


--
-- PostgreSQL database dump complete
--

